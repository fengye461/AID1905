"""
模拟注册/登录
1. 注册:输入用户名/密码  存入数据库
    用户名不能重复
2. 登录:进行比对,有则成功,否则重新输入
"""

import pymysql

# 连接数据库
db = pymysql.connect(host = 'localhost',
                     port = 3306,
                     user = 'root',
                     password = '123456',
                     database = 'stu',
                     charset = 'utf8')

# 获取游标 (操作数据库,执行sql语句)
cur = db.cursor()

s = input("1.注册\n2.登录")


def enroll():
    # global username, password, sql
    username = input("username:")
    password = input("password:")
    try:
        sql = "insert into user values (%s,%s)"
        cur.execute(sql, [username, password])
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        return False


def login():
    # global username, password, sql
    username = input("username:")
    password = input("password:")
    sql = "select username,password from user"
    cur.execute(sql)
    tup = cur.fetchall()
    print(tup)
    if (username, password) not in tup:
        return False
    else:
        return True

if s == '1':
    if enroll():
        print("注册成功")
    else:
        print("用户名重复")

elif s == '2':
    if login():
        print("登录成功")
    else:
        print("请重新输入")

# 关闭数据库
cur.close()
db.close()

