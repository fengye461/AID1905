"""
读取dict.txt文件
插入数据库
"""

import pymysql
import re

pattern = r"(?P<word>\S+)\s+(?P<intepret>(.+))"
regex = re.compile(pattern)

# 连接数据库
db = pymysql.connect(host = 'localhost',
                     port = 3306,
                     user = 'root',
                     password = '123456',
                     database = 'dict',
                     charset = 'utf8')

# 获取游标 (操作数据库,执行sql语句)
cur = db.cursor()

with open('dict.txt') as f:
    for line in f:
        obj = regex.match(line)
        word = obj.group('word')
        intepret = obj.group('intepret')
        # 写数据库
        try:
            # 写sql语句执行
            sql = "insert into words (word,intepret) values (%s,%s)"
            cur.execute(sql,[word,intepret])
            db.commit()      # 提交
        except Exception as e:
            db.rollback()  # 退回到commit执行之前的数据库状态
            print(e)

# 关闭数据库
cur.close()
db.close()





